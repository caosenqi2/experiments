#include "types.h"
#include "user.h"
#include "procThread.h"

int procThread_create(void)
{
  void *stack = malloc(4096);
  return clone(stack);
}


void procThread_exit(int ret_val)
{
  thread_exit(ret_val);
}


void procThread_join(int tid, int * ret_val_p)
{
  void *stack = 0;
  join(tid, ret_val_p, &stack);
  if (stack > 0)
    free(stack);
}

